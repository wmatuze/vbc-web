<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('user');
            $table->char('name');
            $table->char('image');
            $table->char('brand');
            $table->char('category');
            $table->char('description');
            $table->integer('rating');
            $table->integer('numReviews');
            $table->decimal('price');
            $table->integer('countInStock');
            $table->date('createdAt');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product');
    }
}
