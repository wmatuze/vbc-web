<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('order', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('user');
            $table->char('paymentMethod');
            $table->decimal('taxPrice');
            $table->decimal('shippingPrice');
            $table->decimal('totalPrice');
            $table->boolean('isPaid');
            $table->date('paidAt');
            $table->boolean('isDelivered');
            $table->date('deliveredAt');
            $table->date('createdAt');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('order');
    }
}
